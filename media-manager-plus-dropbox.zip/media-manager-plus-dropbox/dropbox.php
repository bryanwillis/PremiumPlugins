<?php
/**
 * Dropbox
 *
 * Media Manager Plus Image Source
 *
 * DISCLAIMER
 *
 * Do not edit or add directly to this file if you wish to upgrade Media Manager Plus to newer
 * versions in the future.
 *
 * @package             Media Manager Plus
 * @category            Image Source
 * @author              Dev7studios
 *
**/
if (class_exists('media_manager_plus_source')) {
	class media_manager_plus_source_dropbox extends media_manager_plus_source {
	  
		public 	$host = 'https://api.dropbox.com/1/';
		public  $format;
		private $access_token_url = 'https://api.dropbox.com/1/oauth2/token';
		private $authenticate_token_url = '';
		private $authorize_url = 'https://api.dropbox.com/1/oauth2/authorize';
		private $request_token_url = '';
		
	 	private $consumer_key = '7fb8vldsnayz6qj';
	 	private $consumer_secret = '823aidc7wfv8vmz';
	 	private $redirect_uri = 'https://app.sellwire.net/files/dropbox.php';
	 		
	 	private $max_count = 25;
	 	private $default_count = 25;
	 	
	 	private $popup_width = 500;
	 	private $popup_height = 400;
	 	
	 	private $settings = array(	
	 								'getFolderImages' => array( 	'name' => "My Images",
	 																'param' => true,
	 																'param_type' => 'text',
	 																'param_default' => '/',
	 																'param_desc' => "Enter Path",
	 																'param_disabled' => true,
	 																'nopagin' => true ),
									);

	 	function __construct($oauth_token = NULL, $oauth_token_secret = NULL) {
	 	
	 		parent::__construct(	$this->host,
	 								$this->format,
	 								$this->access_token_url,
	 								$this->authenticate_token_url,
	 								$this->authorize_url,
	 								$this->request_token_url,
	 								$this->consumer_key,
	 								$this->consumer_secret,
	 								$this->settings,
	 								$this->max_count,
	 								$this->default_count,
	 								$this->popup_width,
	 								$this->popup_height,
	 								$oauth_token,
	 								$oauth_token_secret
	 							);
		}
		
		function getFormat($url) { return "{$this->host}{$url}"; }
		
		function get_param_choices($type = '') {
			if ($type == 'getFolderImages') {
				return $this->getFolders();
			}
		}
		
		function get_authorise_url($callback = '', $source = '') {
			$_SESSION[$source .'_oauth_token'] = $source .'_token';
			$_SESSION[$source .'_oauth_token_secret'] = $source .'_secret';	
			$return_uri = base64_encode($callback. '&type=' . $source);	
			$redirect = $this->redirect_uri;
			$state = base64_encode($callback);	
			$params = array(
			    'response_type' => 'code',
			    'client_id' => $this->consumer_key,
			    'redirect_uri' => $redirect,
			    'state' => $state
			);
			$url = $this->authorize_url.'?'. mmpOAuthUtil::build_http_query($params);
			return $url;
		}
		
	    function getAccessToken($oauth_verifier = FALSE, $return_uri = NULL) {	
			$state = base64_encode($return_uri);
		    $redirect_uri = $this->redirect_uri;
		    $parameters = array(
		    	'client_id' => $this->consumer_key, 
		    	'client_secret' => $this->consumer_secret, 
		    	'code' => $oauth_verifier, 
		    	'redirect_uri' => $redirect_uri, 
		    	'grant_type' => 'authorization_code',
		    );
		    $request = $this->post($this->accessTokenUrl(), $parameters);
	        $token = json_decode($request);
	        if (!$token || $token == '') {
		        parse_str($request);
	        } else {
		        $access_token = $token->access_token;
	        }
	        if ($access_token) {
		        $accesstoken['oauth_token'] = $access_token;
		        $accesstoken['oauth_token_secret'] = 'nosecret';
	        }
	        return $accesstoken;
		}
		
		private function getThumbnail($path) {
			$url = 'thumbnails/dropbox'. $path;
			$token = $this->token;
			$params['access_token'] = $token->key;
			$params['size'] = 'm';
			$url = 'https://api-content.dropbox.com/1/'. $url;
			$url = $url .'?'. mmpOAuthUtil::build_http_query($params);
			return $url;
		}
		
		function getMedia($path) {
			$url = 'shares/dropbox'. $path;
			$parameters['short_url'] = 'false';
			$response = $this->oAuthRequest2($url, 'POST', $parameters);
			$response = json_decode($response);
			return (isset($response->url)) ? $response->url : '';			
		}
		
		private function getImages($images, $folder) {
			$response = array();
			$new_images = array();
			if ($images && isset($images->contents)) {
			    if (isset($images->paging->next)) $response['altpage'] = $images->paging->next;
				else $response['pagin'] = false;
		
			    foreach($images->contents as $photo) {
				
				    $thumb = $this->getThumbnail($photo->path);
					$full = $thumb;
					$link = $photo->path;
					
					$path_parts = pathinfo($photo->path);
					
					$new_image  = array( 	'id' => $photo->rev,
				    						'full' => $full,
				    						'thumbnail' => $thumb,
				    						'link' => $link,
										    'caption' => $path_parts['filename']
				    					);
				    					
				    if (strpos($photo->icon, 'folder') !== false)  {
				    	
				    	$new_image['thumbnail'] = plugins_url( 'assets/img/folder.png' , __FILE__ );
				    	$new_image['folder'] = true;
				    	$new_image['full'] = '';
				    	$new_image['link'] = $photo->path;
				    }
				    	
				    $new_images[] = $new_image;
				    
				}
			}
			$response['images'] = $new_images;
			return $response;
		}		

		function getFolderImages($folder, $count = null, $safemode = 1, $page = 1,  $altpage = '') {
			if ($altpage != '') {
				$response = $this->http($altpage, 'GET');
				$images = json_decode(json_encode(json_decode($response)));
			} else {
				$params = array();
				$images = $this->get('metadata/dropbox'. $folder, $params, 1);
			}
			return $this->getImages($images, $folder);
		}
		
	}
}
