<?php
/*  
Plugin Name: Media Manager Plus: Dropbox
Plugin URI: http://dev7studios.com/media-manager-plus/dropbox
Description: A premium extension to the Media Manager Plus plugin to allow you to access images from Dropbox.
Author: Dev7studios 
Version: 1.1
Author URI: http://dev7studios.com
*/

class media_manager_plus_dropbox {
	private $plugin_version;
	private $required;
	private $source;
	
	function __construct() {
		$this->plugin_version = 1.0;
		
		$this->required = 1.4	;
		$this->source = 'dropbox';
		
		register_activation_hook( __FILE__, array($this, 'activate') );
		
		add_filter( 'uber_media_sources',  array($this,'add_mmp_source'), 10 );
		add_action( 'plugins_loaded',  array($this,'mmp_source_load'), 0 );
		add_filter( 'uber_media_pre_insert', array( $this, 'mmp_pre_insert' ), 1 );
		
		add_filter( 'mmp_feed_exclude',  array($this,'exclude_mmp_source') );
		
		add_action('admin_enqueue_scripts', array($this, 'admin_enqueue_scripts'));
	
		require_once('wp-updates-plugin.php');
        new WPUpdatesPluginUpdater( 'http://wp-updates.com/api/1/plugin', 203, plugin_basename(__FILE__) );
	}
	
	function activate( $network_wide ) {
		$mmp_path = 'uber-media/uber-media.php';
		
		if (!is_plugin_active( $mmp_path )) {
			deactivate_plugins(basename(__FILE__));
			wp_die("This plugin requires the Media Manager Plus plugin to be installed and activated"); 
		}
				
		$default_headers = array( 'Version' => 'Version',  'Name' => 'Plugin Name');
		$plugin_data = get_file_data( dirname( dirname(__FILE__) ) .'/'. $mmp_path, $default_headers, 'plugin' );

		if (version_compare($plugin_data['Version'], $this->required, '<'))  {
			deactivate_plugins(basename(__FILE__));
			wp_die('This plugin requires Media Manager Plus version '. $this->required .' to be installed and activated'); 
		}
	}
	
	function add_mmp_source( $sources ) {
		$sources[$this->source] = array( 	'source' => $this->source,
									 		'imgsrc' => plugins_url( $this->source. '.png' , __FILE__ ) );
		return $sources;
	}
	
	function exclude_mmp_source( $sources ) {
		$sources[$this->source] = $this->source;
		return $sources;
	}
	
	function mmp_source_load() {
		require_once( dirname(__FILE__) . '/'. $this->source .'.php' );
	}
	
	function admin_enqueue_scripts() {       
        wp_register_style( 'mmp-dropbox-css', plugins_url('assets/css/mmp-dropbox.css' , __FILE__ ), array(), $this->plugin_version);
		wp_enqueue_style('mmp-dropbox-css');
    }
    
    function mmp_pre_insert($response) {
		if (!isset($response['fields']['data-link'])) return $response;
		if (!isset($response['fields']['id'])) return $response;
		if (!isset($response['imgsrc'])) return $response;
			
		$settings = get_option('ubermediasettings_settings', array());
		$options = $settings['ubermediasettings_sources_available'];
		$source_settings = $options[$this->source .'-settings'];
	    $access_token = $source_settings['access-token'];
	    
	    $source = 'media_manager_plus_source_'. $this->source;
		$dropbox = new $source($access_token['oauth_token'], $access_token['oauth_token_secret']);
		
		$full = '';
		$link = $dropbox->getMedia($response['fields']['data-link']);
		$full = str_replace('www.', 'dl.', $link);
				
		if($full != '') {
			list($width, $height, $type, $attr) = getimagesize($full);
			$response['imgsrc'] = $full;
			$response['imgwidth'] = $width;
			$response['imgheight'] = $height;
		}
		return $response;
	}
}
$media_manager_plus_source = new media_manager_plus_dropbox();
