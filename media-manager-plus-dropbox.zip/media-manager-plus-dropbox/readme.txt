=== Media Manager Plus: Dropbox ===
Contributors: dev7studios, polevaultweb
Tags: import, media, manager, plus, picasa, 500px, flickr, instagram, dribbble, image, images
Requires at least: 3.4
Tested up to: 3.5.1
Stable tag: 1.1
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A premium extension to the Media Manager Plus plugin to allow you to access your images from Dropbox.

== Description ==

The Media Manager Plus plugin allows your to easily browse images from your Picasa account.

== Installation ==

= Simple Install =

1. Login to WordPress and go to Plugins > Add New > Upload
2. Upload media-manager-plus-dropbox.zip and activate

= Manual Install =

1. Upload the media-manager-plus-dropbox folder to your /wp-content/plugins/ directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.

== Changelog ==

= 1.1 =

* MMP compatibility fixes

= 1.0 =

* Initial release