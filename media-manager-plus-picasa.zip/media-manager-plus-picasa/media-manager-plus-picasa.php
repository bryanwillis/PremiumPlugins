<?php
/*  
Plugin Name: Media Manager Plus: Picasa
Plugin URI: http://dev7studios.com/media-manager-plus/picasa
Description: A premium extension to the Media Manager Plus plugin to allow you to access images from Picasa.
Author: Dev7studios 
Version: 1.1
Author URI: http://dev7studios.com
*/

class media_manager_plus_picasa {
	private $required;
	private $source;
	
	function __construct() {
		$this->required = 1.4;
		$this->source = 'picasa';
		
		register_activation_hook( __FILE__, array($this, 'activate') );
		
		add_filter( 'uber_media_sources',  array($this,'add_mmp_source'), 10 );
		add_action( 'plugins_loaded',  array($this,'mmp_source_load'), 0 );
		
		require_once('wp-updates-plugin.php');
        new WPUpdatesPluginUpdater( 'http://wp-updates.com/api/1/plugin', 202, plugin_basename(__FILE__) );
	}
	
	function activate( $network_wide ) {
		$mmp_path = 'uber-media/uber-media.php';
		
		if (!is_plugin_active( $mmp_path )) {
			deactivate_plugins(basename(__FILE__));
			wp_die("This plugin requires the Media Manager Plus plugin to be installed and activated"); 
		}
				
		$default_headers = array( 'Version' => 'Version',  'Name' => 'Plugin Name');
		$plugin_data = get_file_data( dirname( dirname(__FILE__) ) .'/'. $mmp_path, $default_headers, 'plugin' );

		if (version_compare($plugin_data['Version'], $this->required, '<'))  {
			deactivate_plugins(basename(__FILE__));
			wp_die('This plugin requires Media Manager Plus version '. $this->required .' to be installed and activated'); 
		}
	}
	
	function add_mmp_source( $sources ) {
		$sources[$this->source] = array( 	'source' => $this->source,
									 		'imgsrc' => plugins_url( $this->source. '.png' , __FILE__ ) );
		return $sources;
	}
	
	function mmp_source_load() {
		require_once( dirname(__FILE__) . '/'. $this->source .'.php' );
	}	
}
$media_manager_plus_source = new media_manager_plus_picasa();
