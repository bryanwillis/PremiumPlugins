<?php
/**
 * Picasa
 *
 * Media Manager Plus Image Source
 *
 * DISCLAIMER
 *
 * Do not edit or add directly to this file if you wish to upgrade Media Manager Plus to newer
 * versions in the future.
 *
 * @package             Media Manager Plus
 * @category            Image Source
 * @author              Dev7studios
 *
**/
if (class_exists('media_manager_plus_source')) {
	class media_manager_plus_source_picasa extends media_manager_plus_source {
	  
		public 	$host = 'https://picasaweb.google.com/data/feed/api/';
		public  $format;
		private $access_token_url = 'https://accounts.google.com/o/oauth2/token';
		private $authenticate_token_url = '';
		private $authorize_url = 'https://accounts.google.com/o/oauth2/auth';
		private $request_token_url = '';
		
	 	private $consumer_key = '5549237491.apps.googleusercontent.com';
	 	private $consumer_secret = 'jUys0JxtoRld_Y3ze2-SvYkY';
	 	private $redirect_uri = 'http://dev7studios.com/oauth/picasa.php';
	 		
	 	private $max_count = 25;
	 	private $default_count = 25;
	 	
	 	private $popup_width = 500;
	 	private $popup_height = 400;
	 	
	 	private $settings = array(		 								
	 								'getAlbumImages' => array( 	'name' => 'My Albums',
 																'param' => true,
 																'param_type' => 'select',
 																'param_dynamic' => true),
									);

	 	function __construct($oauth_token = NULL, $oauth_token_secret = NULL) {
	 	
	 		parent::__construct(	$this->host,
	 								$this->format,
	 								$this->access_token_url,
	 								$this->authenticate_token_url,
	 								$this->authorize_url,
	 								$this->request_token_url,
	 								$this->consumer_key,
	 								$this->consumer_secret,
	 								$this->settings,
	 								$this->max_count,
	 								$this->default_count,
	 								$this->popup_width,
	 								$this->popup_height,
	 								$oauth_token,
	 								$oauth_token_secret
	 							);
		}
		
		function getFormat($url) { return "{$this->host}{$url}"; }
		
		function get_param_choices($type = '') {
			if ($type == 'getAlbumImages') {
				return $this->getAlbums();
			}
		}
		
		function get_authorise_url($callback = '', $source = '') {
			$_SESSION[$source .'_oauth_token'] = $source .'_token';
			$_SESSION[$source .'_oauth_token_secret'] = $source .'_secret';	
			$return_uri = base64_encode($callback. '&type=' . $source);	
			$redirect = $this->redirect_uri;
			$state = base64_encode($callback);	
			$params = array(
			    'response_type' => 'code',
			    'client_id' => $this->consumer_key,
			    'redirect_uri' => $redirect,
			    'scope' => 'https://picasaweb.google.com/data/',
			    'state' => $state,
			    'access_type' => 'offline',
			    'approval_prompt' => 'force'
			);
			$url = $this->authorize_url.'?'. mmpOAuthUtil::build_http_query($params);
			return $url;
		}
		
	    function getAccessToken($oauth_verifier = FALSE, $return_uri = NULL) {	
			$state = base64_encode($return_uri);
		    $redirect_uri = $this->redirect_uri;
		    $parameters = array(
		    	'client_id' => $this->consumer_key, 
		    	'client_secret' => $this->consumer_secret, 
		    	'code' => $oauth_verifier, 
		    	'redirect_uri' => $redirect_uri, 
		    	'grant_type' => 'authorization_code',
		    	
		    	
		    );
		    $request = $this->post($this->accessTokenUrl(), $parameters);
	        $token = json_decode($request);
	        if (!$token || $token == '') {
		        parse_str($request);
	        } else {
		        $access_token = $token->access_token;
	        }
	        if ($access_token) {
		        $accesstoken['oauth_token'] = $access_token;
		        $accesstoken['oauth_token_secret'] = 'nosecret';
		        $accesstoken['refresh_token'] = $token->refresh_token;
		        $accesstoken['expiry'] = time() + $token->expires_in;
	        }
	        return $accesstoken;
		}
		
		/*
		function refreshToken() {	
		    $source = 'picasa';
		    $options = get_option('ubermediasettings_settings', array());
		    if (!$options) return;
		    $sources = $options['ubermediasettings_sources_available'];
		    $picasa = $sources[$source .'-settings'];
		   // _log($picasa);
			
			if ($picasa['access-token']['expiry'] < time()) {
				//_log('expiry: '. $picasa['access-token']['expiry'] . ' less than now: '. time() );
				return;
			}
			
		    $parameters = array(
		    	'client_id' => $this->consumer_key, 
		    	'client_secret' => $this->consumer_secret, 
		    	'refresh_token' => $picasa['access-token']['refresh_token'], 
		    	'grant_type' => 'refresh_token',
		    );
		    $request = $this->post($this->accessTokenUrl(), $parameters);
	        $token = json_decode($request);
	        if (!$token || $token == '') {
		        parse_str($request);
	        } else {
		        $access_token = $token->access_token;
	        }
	        $picasa['access-token']['oauth_token'] = $access_token;
	        $picasa['access-token']['expiry'] = time() + $token->expires_in;
	        
	        $sources[$source .'-settings'] = $picasa;
	        $save_options = $options;
		    $save_options['ubermediasettings_sources_available'] = $sources;
			update_option('ubermediasettings_settings', $save_options);
			return $access_token;
		} */

		
		private function getImages($images) {
			$response = array();
			$new_images = array();
			$xml = new SimpleXMLElement($images);
			$xml->registerXPathNamespace('media', 'http://search.yahoo.com/mrss/'); // define namespace media 
			 
			if (isset($xml->entry)) {
		    	foreach($xml->entry as $feed) {
		    		$photo_url = explode('/', (string)$feed->id);
		    		$thumb = $feed->xpath('./media:group/media:thumbnail');
		    		$full = $feed->xpath('./media:group/media:content');
					$description = $feed->xpath('./media:group/media:description');
					$caption = (string)$description[0];
					if ($caption == '') $caption = (string)$feed->title;
				
			        $thumbail = $thumb[0]->attributes(); 
			        $full_image = $full[0]->attributes();
					$b = $feed->content->attributes();
		   
		    		$new_images[] = array( 	'id' => end($photo_url),
											'full' => (string)$full_image['url'],
											'thumbnail' => (string)$thumbail['url'],//$thumbnail->attributes()->{'url'},
											'link' => (string)$full_image['url'],
										    'caption' => $this->filter_text($caption) 
										);
		    	}
		    }
			$response['images'] = $new_images;
			return $response;
		}
		
		function getAlbums() {
			$params = array();
			$response = $this->oAuthRequest2('user/default', 'GET', $params);  
			if (trim($response) == 'Token invalid - Invalid token: Stateless token expired') {
				
				$source = 'picasa';
				$settings = get_option('ubermediasettings_settings', array());
				if (!$settings) return;
				$options = $settings['ubermediasettings_sources_available'];
				
				if (isset($options[$source .'-settings'])) {
					unset($options[$source .'-settings']);
					$save_options = $settings;
					$save_options['ubermediasettings_sources_available'] = $options;
					update_option('ubermediasettings_settings', $save_options);
				}    
				
				$new_albums[''] = 'Token expired. Reconnect Picasa';
				return $new_albums;
			}
			$new_albums = array();
			$new_albums[''] = 'Select Album';
			$xml = new SimpleXMLElement($response);
			$namespaces = $xml->getNamespaces(true);
		    if (isset($xml->entry)) {
		    	foreach($xml->entry as $album) {
		    		$album_url = explode('/', (string)$album->id);
		    		$new_albums[end($album_url)] = (string)$album->title;
		    	}
		    }
			return $new_albums;
		}
		
		function getAlbumImages($album_id, $count = null, $safemode = 1, $page = 1,  $altpage = '') {
			if ($altpage != '') {
				$response = $this->http($altpage, 'GET');
				$images = json_decode(json_encode(json_decode($response)));
			} else {
				$count = ($count > $this->max_count) ? $this->max_count : $count;
				$params = ($count == $this->default_count) ? array() : array( 'limit' => $count );
				$params['imgmax'] = 'd';
				$images = $this->oAuthRequest2('user/default/albumid/'. $album_id, 'GET', $params);  
			}
			return $this->getImages($images);
		}
		
	}
}
